package com.example.web;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

public class AwesomeThingsService {

	public Page<AwesomeThing> getAwesomeThings(PageRequest newPgb) {
		// TODO Auto-generated method stub
		return null;
	}

}
