INSERT INTO customers (first_name, last_name,version) VALUES ('Nobita', 'Nobi',0);
INSERT INTO customers (first_name, last_name,version) VALUES ('Takeshi', 'Goda',0);
INSERT INTO customers (first_name, last_name,version) VALUES ('Suneo', 'Honekawa',0);
INSERT INTO customers (first_name, last_name,version) VALUES ('Shizuka', 'Minamoto',0);