package com.example.web;

public class AwesomeThing {

}
