package com.example.service;

import java.util.List;

import com.example.mapper.Users;
import com.example.mapper.UsersExample;
import com.example.mapper.UsersMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class LoginUserDetailsService implements UserDetailsService {
    @Autowired
    UsersMapper usersMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    	//User user = new User();
    	UsersExample usersExample = new UsersExample();
    	usersExample.createCriteria().andUsernameEqualTo(username);
        List<Users> user = usersMapper.selectByExample(usersExample);
        if (user == null) {
            throw new UsernameNotFoundException("The requested user is not found.");
        }
        return new LoginUserDetails(user.get(0));
    }
}
