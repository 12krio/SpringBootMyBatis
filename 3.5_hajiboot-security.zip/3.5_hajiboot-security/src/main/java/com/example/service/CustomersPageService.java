package com.example.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.mapper.Customers;
import com.example.mapper.CustomersCriteria;
import com.example.mapper.CustomersRepo;

@Transactional
@Service
public class CustomersPageService {

    @Autowired
    CustomersRepo customersRepo;

    @Transactional(readOnly = true)
    //@Override
    public Page<Customers> searchCustomers(CustomersCriteria criteria,
            Pageable pageable) {
        long total = customersRepo.countByCriteria(criteria);
        List<Customers> todos;
        if (0 < total) {
            // (5)
            todos = customersRepo.findPageByCriteria(criteria,
                    pageable);
        } else {
            todos = Collections.emptyList();
        }
        return new PageImpl<>(todos, pageable, total);
    }

    // omitted

}
