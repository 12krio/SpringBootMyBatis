package com.example.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.data.domain.Pageable;

public interface CustomersRepo {

    // (1)
    long countByCriteria(
            @Param("criteria") CustomersCriteria criteria);

    // (2)
    List<Customers> findPageByCriteria(
            @Param("criteria") CustomersCriteria criteria,
            @Param("pageable") Pageable pageable);

}
