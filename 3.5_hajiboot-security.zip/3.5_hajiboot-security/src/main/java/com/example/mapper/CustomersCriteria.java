package com.example.mapper;

public class CustomersCriteria {

}
