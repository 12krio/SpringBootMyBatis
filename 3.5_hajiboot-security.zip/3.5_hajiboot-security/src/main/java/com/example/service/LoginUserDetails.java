package com.example.service;

import com.example.mapper.Users;

import lombok.Data;

import org.springframework.security.core.authority.AuthorityUtils;

@Data
public class LoginUserDetails extends org.springframework.security.core.userdetails.User {
    private final Users user;

    public LoginUserDetails(Users user) {
        super(user.getUsername(), user.getEncodedPassword(), AuthorityUtils.createAuthorityList("ROLE_USER"));
        this.user = user;
    }

	public Users getUser() {
		// TODO Auto-generated method stub
		return user;
	}
}
