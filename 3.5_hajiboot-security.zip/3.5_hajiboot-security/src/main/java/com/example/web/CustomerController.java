package com.example.web;

import com.example.mapper.Customers;
import com.example.service.CountryService;
import com.example.service.CustomerService;
import com.example.service.LoginUserDetails;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.web.bind.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import java.util.List;

@Controller
@RequestMapping("customers")
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @ModelAttribute
    CustomerForm setUpForm() {
        return new CustomerForm();
    }
///////////////////////////////////
    @Autowired
    CountryService countryService;

    private static final int DEFAULT_PAGEABLE_SIZE = 2;

    @RequestMapping
    public String index(@Validated CountryListForm countryListForm
            , BindingResult bindingResult
            , @PageableDefault(size = DEFAULT_PAGEABLE_SIZE, page = 0) Pageable pageable
            , Model model) {

        if (bindingResult.hasErrors()) {
            return "countryList";
        }

        countryListForm.setSize(pageable.getPageSize());
        countryListForm.setPage(pageable.getPageNumber());

        Page<Customers> page = countryService.findCountry(countryListForm, pageable);
        PagenationHelper ph = new PagenationHelper(page);

        model.addAttribute("page", page);
        model.addAttribute("ph", ph);

        return "countryList";
    }

    @RequestMapping(method = RequestMethod.GET)
    String list(@Validated CountryListForm countryListForm,
            BindingResult result,
             @PageableDefault(size = DEFAULT_PAGEABLE_SIZE, page = 0)Pageable pageable,
            Model model) {

//    	MyBatisを使用してデータベースにアクセスする場合は、Controllerから受け取った 
//    	Pageable オブジェクトより、必要な情報を抜き出してRepositoryに引き渡す。
//    	該当データを抽出するためのSQLやソート条件については、SQLマッピングで実装する必要がある
//        ArticleSearchCriteria criteria = beanMapper.map(form,
//        ArticleSearchCriteria.class);
//        Page<Article> page = articleService.searchArticle(criteria, pageable); // (2)
//        model.addAttribute("page", page); // (3)

        List<Customers> customers = customerService.findAll();
        model.addAttribute("customers", customers);
///////////////////////////////////////////////////////////
        int num = pageable.getPageNumber();
        if(num == 0){
        	num = 0;
        }else{
        	num = num - 1;        	
        }
        PageRequest newPgb = new PageRequest(num, 20);
        //Pagination variables
        countryListForm.setSize(pageable.getPageSize());
        countryListForm.setPage(pageable.getPageNumber());
        Page<Customers> currentResults = countryService.findCountry(countryListForm, pageable);
        model.addAttribute("currentResults", currentResults);
        
        int current = currentResults.getNumber() + 1;
        int begin = Math.max(1, current - 5);
        int end = Math.min(begin + 10, currentResults.getTotalPages()); // how many pages to display in the pagination bar

        model.addAttribute("beginIndex", begin);
        model.addAttribute("endIndex", end);
        model.addAttribute("currentIndex", current);
        
 ////////////////////////////////////////////////////////
        
//        countryListForm.setSize(2);
        countryListForm.setSize(pageable.getPageSize());
        countryListForm.setPage(pageable.getPageNumber());
        countryListForm.setLimitpage(pageable.getPageSize()*pageable.getPageNumber());
        Page<Customers> page = countryService.findCountry(countryListForm, pageable);
        PagenationHelper ph = new PagenationHelper(page);

        model.addAttribute("page", page);
        model.addAttribute("ph", ph);        
        
        
        
        return "customers/list";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    String create(@Validated CustomerForm form, BindingResult result, Model model,
                  @AuthenticationPrincipal LoginUserDetails userDetails) {
        if (result.hasErrors()) {
//            return list(model);
        }
//        Customer customer = new Customer();
//        BeanUtils.copyProperties(form, customer);
//        customerService.create(customer, userDetails.getUser());
        return "redirect:/customers";
    }

    @RequestMapping(value = "edit", params = "form", method = RequestMethod.GET)
    String editForm(@RequestParam Integer id, CustomerForm form) {
//        Customer customer = customerService.findOne(id);
//        BeanUtils.copyProperties(customer, form);
        return "customers/edit";
    }

    @RequestMapping(value = "edit", method = RequestMethod.POST)
    String edit(@RequestParam Integer id, @Validated CustomerForm form, BindingResult result,
                @AuthenticationPrincipal LoginUserDetails userDetails) {
        if (result.hasErrors()) {
            return editForm(id, form);
        }
        //Customer customer = new Customer();
        
//        Customer customer =customerService.findOne(id);
//        if(customer.getVersion() != customer.getVersion()){
//        	
//        }
//        BeanUtils.copyProperties(form, customer);
//        //customer.setId(id);
//        customerService.update(customer, userDetails.getUser());
        return "redirect:/customers";
    }

    @RequestMapping(value = "edit", params = "goToTop")
    String goToTop() {
        return "redirect:/customers";
    }

    @RequestMapping(value = "delete", method = RequestMethod.POST)
    String delete(@RequestParam Integer id) {
//        customerService.delete(id);
        return "redirect:/customers";
    }
}
