package com.example.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.mapper.Customers;
import com.example.mapper.CustomersMapper;
import com.example.web.CountryListForm;

import java.util.Collections;
import java.util.List;

@Service
public class CountryService {

    @Autowired
    private CustomersMapper countryMapper;

    public Page<Customers> findCountry(CountryListForm countryListForm, Pageable pageable) {
        long count = countryMapper.selectCountryCount(countryListForm);
        System.out.println("count="+count);
        List<Customers> countryList = Collections.emptyList();
        if (count > 0) {
            countryList = countryMapper.selectCountry(countryListForm);
            System.out.println("countryList="+countryList);
        }

        return new PageImpl<>(countryList, pageable, count);
    }

}
