package com.example.service;

import com.example.mapper.Customers;
import com.example.mapper.CustomersExample;
import com.example.mapper.CustomersMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CustomerService {
    @Autowired
    CustomersMapper customersMapper;

    public List<Customers> findAll() {
    	CustomersExample customersExample = new CustomersExample();
        return customersMapper.selectByExample(customersExample);
    }
//
//    public Customer findOne(Integer id) {
//        return customerRepository.findOne(id);
//    }
//
//    public Customer create(Customer customer, User user) {
//        customer.setUser(user);
//        return customerRepository.save(customer);
//    }
//
//    public Customer update(Customer customer, User user) {
//        customer.setUser(user);
//        return customerRepository.save(customer);
//    }
//
//    public void delete(Integer id) {
//        customerRepository.delete(id);
//    }
}
